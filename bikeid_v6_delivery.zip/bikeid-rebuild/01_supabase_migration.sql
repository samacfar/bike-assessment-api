-- BikeID v2 Schema Migration
-- Run this in Supabase SQL Editor
-- Safe to re-run (uses IF NOT EXISTS)

-- Assessments table
create table if not exists assessments (
    id          uuid primary key default gen_random_uuid(),
    session_id  uuid not null,
    assessment  jsonb not null,
    image_count integer not null default 1,
    created_at  timestamptz not null default now()
);

-- Accuracy log — raw AI output + human verdict
create table if not exists accuracy_log (
    id                  uuid primary key default gen_random_uuid(),
    assessment_id       uuid references assessments(id),
    component_field     text not null,
    ai_original_answer  text,
    human_verdict       text default 'pending',
    corrected_value     text,
    created_at          timestamptz not null default now()
);

-- Corrections — learning signals from challenge notes
create table if not exists corrections (
    id               uuid primary key default gen_random_uuid(),
    session_id       uuid,
    make             text,
    model            text,
    field            text not null,
    challenge_note   text,
    corrected_value  text not null,
    created_at       timestamptz not null default now()
);

-- Brand visual fingerprints
create table if not exists brand_reference (
    id             uuid primary key default gen_random_uuid(),
    brand          text unique not null,
    reference_data jsonb not null,
    updated_at     timestamptz not null default now()
);

-- Indexes
create index if not exists idx_assessments_session on assessments(session_id);
create index if not exists idx_accuracy_log_assessment on accuracy_log(assessment_id);
create index if not exists idx_corrections_make_model on corrections(make, model);
create index if not exists idx_brand_reference_brand on brand_reference(brand);
